# ApproxSciMate
A python library for approximating SciPy functions.
